# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 11:10:03 2022

@author: bere240
"""

import pandas as pd
import numpy as np

df_C=pd.read_csv('input/measurement_data_FPI.csv')
df_MA=pd.read_csv('input/results_data_matlab_CE.csv')#results_data_matlab_CE;results_data_MA_A

df_C['timestamp']=df_MA['timestamp']

angle_c=df_MA[df_MA.columns[2::2]]
angle_c.columns
mag_c=df_MA[df_MA.columns[1::2]]
mag_c.columns

names=list()
names.append('timestamp')
for i in mag_c.columns:
    names.append(i)
for i in angle_c.columns:
    names.append(i)

df_C.columns=names

df_C = df_C[list(df_MA.columns)]

df_C.to_csv('input/FPI_with_corected_columns_names.csv',index=False)




# df_MA=df_MA.drop(columns='timestamp')
# df_C=df_C.drop(columns='timestamp')

# ang_MA=df_MA[df_MA.columns[1::2]]
# ang_FPI=df_C[df_C.columns[144::]]

# ang_FPI.columns=ang_MA.columns

# error=ang_FPI-ang_MA

# print(error.max())

# oi=error.max()

# oi=pd.DataFrame({'max':oi})

# oi['mean']=error.mean()
# oi['min']=error.min()

# oi.to_csv('eval angle summary.csv')

# error.max().max()

# diff=df_C-df_MA

 
# diff.columns()
