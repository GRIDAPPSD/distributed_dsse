# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 11:10:03 2022

@author: bere240
"""

import pandas as pd
import numpy as np

df_C=pd.read_csv('input/FPI_with_corected_columns_names.csv')
df_area=pd.read_csv('input/vnom.csv')

start='area'
time=0
#results_data.csv.0
area=list()
for i in list(df_area.columns):
    if start in i:
        area.append(i)

# i=0
for i in range(len(area)):
    name=area[i]
    nodes=list(df_area.loc[df_area[name]==1,'nodename'])
    cnames_vmag=[j+i for i in nodes for j in ['vmag_']]
    cnames_varg=[j+i for i in nodes for j in ['varg_']]
    cnames=[j+i for i in nodes for j in ['vmag_','varg_']]
    cnames.insert(0,'timestamp')
    df=df_C[cnames]
    df.to_csv('output/t_FPI_results_data.csv.'+str(i),index=False)
    
    df=df.loc[df['timestamp']==time]
    df=df.drop(columns='timestamp')
    
    dff=pd.DataFrame({'nodename':nodes,'vmag':df[cnames_vmag].values.tolist()[0],'varg':df[cnames_varg].values.tolist()[0]})
    dff.to_csv('output/FPI_results_data_c.csv.'+str(i),index=False)
    dff.to_csv('output/FPI_results_data.csv.'+str(i),index=False,header=False)




# df_MA=pd.read_csv('input/results_data_matlab_CE.csv')#results_data_matlab_CE;results_data_MA_A

# df_C['timestamp']=df_MA['timestamp']

# angle_c=df_MA[df_MA.columns[2::2]]
# angle_c.columns
# mag_c=df_MA[df_MA.columns[1::2]]
# mag_c.columns

# names=list()
# names.append('timestamp')
# for i in mag_c.columns:
#     names.append(i)
# for i in angle_c.columns:
#     names.append(i)

# df_C.columns=names

# df_C = df_C[list(df_MA.columns)]

# df_C.to_csv('input/FPI_with_corected_columns_names.csv',index=False)




# df_MA=df_MA.drop(columns='timestamp')
# df_C=df_C.drop(columns='timestamp')

# ang_MA=df_MA[df_MA.columns[1::2]]
# ang_FPI=df_C[df_C.columns[144::]]

# ang_FPI.columns=ang_MA.columns

# error=ang_FPI-ang_MA

# print(error.max())

# oi=error.max()

# oi=pd.DataFrame({'max':oi})

# oi['mean']=error.mean()
# oi['min']=error.min()

# oi.to_csv('eval angle summary.csv')

# error.max().max()

# diff=df_C-df_MA

 
# diff.columns()
